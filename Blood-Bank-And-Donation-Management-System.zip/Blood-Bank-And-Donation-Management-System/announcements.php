<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>

<body>
  <?php include('head.php') ?>
  <div class="container">
    <div class="row">
      <div class="col">
        <img class="card-img-top" src="image\Apollo.jpg" alt="Card image" style="width:100%;height:600px">
      </div>
    </div>
    <div class="row mt-4">
      <div class="col">
        <h2>Announcements</h2>
        <form method="post" action="">
          <div class="form-group">
            <label for="name">Name:</label>
            <input type="text" class="form-control" id="name" name="name" required>
          </div>
          <div class="form-group">
            <label for="age">Age:</label>
            <input type="number" class="form-control" id="age" name="age" required>
          </div>
          <div class="form-group">
            <label for="purpose">Purpose:</label>
            <input type="text" class="form-control" id="purpose" name="purpose" required>
          </div>
          <div class="form-group">
            <label for="blood_group">Blood Group Needed:</label>
            <input type="text" class="form-control" id="blood_group" name="blood_group" required>
          </div>
          <button type="submit" class="btn btn-primary">Submit</button>
        </form>

        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
          // Retrieve form data
          $name = $_POST['name'];
          $age = $_POST['age'];
          $purpose = $_POST['purpose'];
          $blood_group = $_POST['blood_group'];

          // Output the announcement
          echo "<h3>New Announcement:</h3>";
          echo "<p>Name: $name</p>";
          echo "<p>Age: $age</p>";
          echo "<p>Purpose: $purpose</p>";
          echo "<p>Blood Group Needed: $blood_group</p>";
        }
        ?>
      </div>
    </div>
  </div>
  <?php include 'footer.php' ?>
</body>

</html>